<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prova2 - Menu principal</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>
    <h1 id="menu_text">Menu principal - Prova 2</h1>
    <hr>
    <div id="menu">
        <ul>
            <li><a href="pags/cadastro_fluxo_caixa.html"> Cadastro fluxo de caixa</a></li>
            <li><a href="pags/listar_fluxo_caixa.php"> Listagem de fluxo de caixa</a></li>
            <li><a href="pags/consulta_fluxo_caixa.html"> Consulta saldo de caixa</a></li>
        </ul>
    </div> 
</body>
</html>